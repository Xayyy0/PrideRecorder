package com.grabador.pantalla

import android.content.Context

object Settings {
    val resolutions = listOf("480p", "720p (HD)", "1080p (Full HD)", "1440p (2K)", "Nativa")
    val resHeights = listOf(480, 720, 1080, 1440, 0)
    val fpsList = listOf(24, 30, 45, 60, 90, 120)
    val qualities = listOf("Baja", "Media", "Alta", "Muy alta")
    val qualityFactor = listOf(0.04, 0.07, 0.10, 0.15)
    val audioModes = listOf("Interno + micrófono", "Solo interno", "Solo micrófono", "Sin audio")
    val countdowns = listOf("Sin temporizador", "3 segundos", "5 segundos", "10 segundos")
    val countSecs = listOf(0, 3, 5, 10)
    val btnSizes = listOf("Pequeño", "Mediano", "Grande")
    val btnScale = listOf(0.8f, 1f, 1.25f)
    val themes = listOf("Claro", "Oscuro", "Según el sistema")

    private fun prefs(c: Context) = c.getSharedPreferences("ajustes", Context.MODE_PRIVATE)
    fun get(c: Context, key: String, def: Int) = prefs(c).getInt(key, def)
    fun set(c: Context, key: String, v: Int) = prefs(c).edit().putInt(key, v).apply()

    // Por defecto: 1080p, 60 fps, calidad Alta, audio interno + micrófono
    fun res(c: Context) = get(c, "res", 2)
    fun fps(c: Context) = get(c, "fps", 3)
    fun quality(c: Context) = get(c, "quality", 2)
    fun audio(c: Context) = get(c, "audio", 0)
    fun force(c: Context) = get(c, "force", 0)          // 0 = sí forzar
    fun countdown(c: Context) = get(c, "countdown", 1)
    fun btnSize(c: Context) = get(c, "btnsize", 1)
    fun theme(c: Context) = get(c, "theme", 0)

    fun overlayOn(c: Context) = prefs(c).getBoolean("overlay_on", false)
    fun setOverlay(c: Context, on: Boolean) = prefs(c).edit().putBoolean("overlay_on", on).apply()

    fun reset(c: Context) {
        val e = prefs(c).edit()
        for (k in listOf("res", "fps", "force", "quality", "audio", "countdown", "btnsize", "theme")) e.remove(k)
        e.apply()
    }
}
