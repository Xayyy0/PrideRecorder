package com.grabador.pantalla

import android.content.Context

object Settings {
    val resolutions = listOf("480p", "720p", "1080p", "1440p", "Nativa")
    val resHeights = listOf(480, 720, 1080, 1440, 0)
    val fpsList = listOf(24, 30, 45, 60, 90, 120)
    val qualities = listOf("Baja", "Media", "Alta", "Muy alta")
    val qualityFactor = listOf(0.04, 0.07, 0.10, 0.15)
    val audioModes = listOf("Interno + micrófono", "Solo interno", "Solo micrófono", "Sin audio")

    // Por defecto: 1080p, 60 fps, calidad Alta, audio interno + micrófono
    private fun prefs(c: Context) = c.getSharedPreferences("ajustes", Context.MODE_PRIVATE)
    fun get(c: Context, key: String, def: Int) = prefs(c).getInt(key, def)
    fun set(c: Context, key: String, v: Int) = prefs(c).edit().putInt(key, v).apply()

    fun res(c: Context) = get(c, "res", 2)
    fun fps(c: Context) = get(c, "fps", 3)
    fun quality(c: Context) = get(c, "quality", 2)
    fun audio(c: Context) = get(c, "audio", 0)
}
