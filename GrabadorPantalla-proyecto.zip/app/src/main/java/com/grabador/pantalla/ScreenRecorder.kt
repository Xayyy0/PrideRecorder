package com.grabador.pantalla

import android.content.ContentValues
import android.content.Context
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.view.Surface
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Graba pantalla (H.264) + audio interno y/o micrófono (AAC) a un MP4 en Películas/GrabadorPantalla.
 * audioMode: 0 = interno+mic, 1 = solo interno, 2 = solo mic, 3 = sin audio
 */
class ScreenRecorder(
    private val ctx: Context,
    private val projection: MediaProjection,
    private val width: Int,
    private val height: Int,
    private val dpi: Int,
    private var fps: Int,
    private val bitrate: Int,
    private val audioMode: Int,
    private val micAllowed: Boolean
) {
    private val SAMPLE_RATE = 44100
    private val useInternal = audioMode == 0 || audioMode == 1
    private val useMic = (audioMode == 0 || audioMode == 2) && micAllowed
    private val hasAudio = useInternal || useMic

    private var videoEnc: MediaCodec? = null
    private var audioEnc: MediaCodec? = null
    private var inputSurface: Surface? = null
    private var display: VirtualDisplay? = null
    private var muxer: MediaMuxer? = null
    private var pfd: ParcelFileDescriptor? = null
    private var uri: Uri? = null
    private var internalRec: AudioRecord? = null
    private var micRec: AudioRecord? = null

    private val lock = Object()
    private var videoTrack = -1
    private var audioTrack = -1
    private var muxerStarted = false
    private var finished = false
    @Volatile private var running = false
    private var startUs = 0L
    private var videoBaseUs = -1L
    private var lastVideoPts = -1L
    private var lastAudioPts = -1L

    private var videoThread: Thread? = null
    private var audioThread: Thread? = null

    fun start() {
        // Archivo de salida
        val name = "Grabacion_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date()) + ".mp4"
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/GrabadorPantalla")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        uri = ctx.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("No se pudo crear el archivo")
        pfd = ctx.contentResolver.openFileDescriptor(uri!!, "rw")
        muxer = MediaMuxer(pfd!!.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

        // Codificador de video (si falla con estos FPS, baja a 30)
        videoEnc = try { createVideoEncoder(fps) } catch (e: Exception) { fps = 30; createVideoEncoder(30) }
        inputSurface = videoEnc!!.createInputSurface()
        videoEnc!!.start()

        // Audio
        if (hasAudio) setupAudio()

        projection.registerCallback(object : MediaProjection.Callback() {}, null)
        display = projection.createVirtualDisplay(
            "GrabadorPantalla", width, height, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            inputSurface, null, null
        )

        startUs = System.nanoTime() / 1000
        running = true
        videoThread = Thread({ videoLoop() }, "video-drain").also { it.start() }
        if (hasAudio) audioThread = Thread({ audioLoop() }, "audio-loop").also { it.start() }
    }

    private fun createVideoEncoder(f: Int): MediaCodec {
        val fmt = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
            setInteger(MediaFormat.KEY_FRAME_RATE, f)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            setInteger(MediaFormat.KEY_BITRATE_MODE, MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR)
            setLong(MediaFormat.KEY_REPEAT_PREVIOUS_FRAME_AFTER, 1_000_000L / f)
        }
        val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        try {
            enc.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        } catch (e: Exception) {
            enc.release(); throw e
        }
        return enc
    }

    @Suppress("MissingPermission")
    private fun setupAudio() {
        val fmtIn = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(SAMPLE_RATE)
            .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
            .build()
        val minStereo = AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT)
        if (useInternal) {
            val cfg = AudioPlaybackCaptureConfiguration.Builder(projection)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .build()
            internalRec = AudioRecord.Builder()
                .setAudioFormat(fmtIn)
                .setBufferSizeInBytes(minStereo * 4)
                .setAudioPlaybackCaptureConfig(cfg)
                .build()
        }
        if (useMic) {
            val minMono = AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            micRec = AudioRecord(
                MediaRecorder.AudioSource.MIC, SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, minMono * 4
            )
        }
        val afmt = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, SAMPLE_RATE, 2).apply {
            setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            setInteger(MediaFormat.KEY_BIT_RATE, 192_000)
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
        }
        audioEnc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC).also {
            it.configure(afmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            it.start()
        }
        internalRec?.startRecording()
        micRec?.startRecording()
    }

    // ---- Video ----
    private fun videoLoop() {
        val enc = videoEnc ?: return
        val info = MediaCodec.BufferInfo()
        try {
            while (true) {
                val idx = enc.dequeueOutputBuffer(info, 10_000)
                when {
                    idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> addTrack(true, enc.outputFormat)
                    idx >= 0 -> {
                        val buf = enc.getOutputBuffer(idx)
                        val eos = info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                        if (buf != null && info.size > 0 && info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG == 0) {
                            if (videoBaseUs < 0) videoBaseUs = info.presentationTimeUs
                            var pts = info.presentationTimeUs - videoBaseUs
                            if (pts <= lastVideoPts) pts = lastVideoPts + 1
                            lastVideoPts = pts
                            info.presentationTimeUs = pts
                            writeSample(true, buf, info)
                        }
                        enc.releaseOutputBuffer(idx, false)
                        if (eos) break
                    }
                }
            }
        } catch (_: Exception) {
        }
    }

    // ---- Audio ----
    private fun audioLoop() {
        val enc = audioEnc ?: return
        val stereo = ShortArray(2048)   // 1024 frames estéreo
        val mono = ShortArray(1024)
        val bytes = ByteArray(2048 * 2)
        var frames = 0L
        val firstUs = System.nanoTime() / 1000 - startUs
        try {
            while (running) {
                java.util.Arrays.fill(stereo, 0)
                internalRec?.let { rec ->
                    var got = 0
                    while (got < stereo.size && running) {
                        val n = rec.read(stereo, got, stereo.size - got, AudioRecord.READ_BLOCKING)
                        if (n <= 0) break
                        got += n
                    }
                }
                micRec?.let { rec ->
                    var got = 0
                    while (got < mono.size && running) {
                        val n = rec.read(mono, got, mono.size - got, AudioRecord.READ_BLOCKING)
                        if (n <= 0) break
                        got += n
                    }
                    for (i in stereo.indices) {
                        val m = stereo[i] + mono[i / 2]
                        stereo[i] = m.coerceIn(-32768, 32767).toShort()
                    }
                }
                for (i in stereo.indices) {
                    bytes[i * 2] = (stereo[i].toInt() and 0xFF).toByte()
                    bytes[i * 2 + 1] = (stereo[i].toInt() shr 8).toByte()
                }
                val pts = firstUs + frames * 1_000_000L / SAMPLE_RATE
                feedAudio(enc, bytes, bytes.size, pts, false)
                frames += stereo.size / 2
                drainAudio(enc, false)
            }
            feedAudio(enc, bytes, 0, firstUs + frames * 1_000_000L / SAMPLE_RATE, true)
            drainAudio(enc, true)
        } catch (_: Exception) {
        }
    }

    private fun feedAudio(enc: MediaCodec, data: ByteArray, len: Int, pts: Long, eos: Boolean) {
        val idx = enc.dequeueInputBuffer(if (eos) 500_000 else 10_000)
        if (idx < 0) return
        val buf = enc.getInputBuffer(idx) ?: return
        buf.clear()
        if (len > 0) buf.put(data, 0, len)
        enc.queueInputBuffer(idx, 0, len, pts, if (eos) MediaCodec.BUFFER_FLAG_END_OF_STREAM else 0)
    }

    private fun drainAudio(enc: MediaCodec, untilEos: Boolean) {
        val info = MediaCodec.BufferInfo()
        var retries = 0
        while (true) {
            val idx = enc.dequeueOutputBuffer(info, if (untilEos) 100_000 else 0)
            when {
                idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> addTrack(false, enc.outputFormat)
                idx >= 0 -> {
                    val buf = enc.getOutputBuffer(idx)
                    val eos = info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                    if (buf != null && info.size > 0 && info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG == 0) {
                        var pts = info.presentationTimeUs
                        if (pts <= lastAudioPts) pts = lastAudioPts + 1
                        lastAudioPts = pts
                        info.presentationTimeUs = pts
                        writeSample(false, buf, info)
                    }
                    enc.releaseOutputBuffer(idx, false)
                    if (eos) return
                }
                idx == MediaCodec.INFO_TRY_AGAIN_LATER -> if (!untilEos || ++retries > 30) return
            }
        }
    }

    // ---- Muxer ----
    private fun addTrack(isVideo: Boolean, format: MediaFormat) = synchronized(lock) {
        val m = muxer ?: return@synchronized
        val t = m.addTrack(format)
        if (isVideo) videoTrack = t else audioTrack = t
        if (videoTrack >= 0 && (!hasAudio || audioTrack >= 0) && !muxerStarted) {
            m.start()
            muxerStarted = true
            lock.notifyAll()
        }
    }

    private fun writeSample(isVideo: Boolean, buf: java.nio.ByteBuffer, info: MediaCodec.BufferInfo) {
        synchronized(lock) {
            var waited = 0
            while (!muxerStarted && !finished && waited < 30) { lock.wait(100); waited++ }
            if (!muxerStarted || finished) return
            buf.position(info.offset)
            buf.limit(info.offset + info.size)
            muxer!!.writeSampleData(if (isVideo) videoTrack else audioTrack, buf, info)
        }
    }

    /** Detiene todo y devuelve el Uri del video guardado (o null si falló). */
    fun stop(): Uri? {
        if (!running && videoThread == null) return null
        running = false
        try { display?.release() } catch (_: Exception) {}
        try { videoEnc?.signalEndOfInputStream() } catch (_: Exception) {}
        try { audioThread?.join(4000) } catch (_: Exception) {}
        try { videoThread?.join(4000) } catch (_: Exception) {}
        synchronized(lock) { finished = true; lock.notifyAll() }
        try { internalRec?.stop() } catch (_: Exception) {}
        try { micRec?.stop() } catch (_: Exception) {}
        internalRec?.release(); micRec?.release()
        try { videoEnc?.stop() } catch (_: Exception) {}
        try { audioEnc?.stop() } catch (_: Exception) {}
        videoEnc?.release(); audioEnc?.release()
        inputSurface?.release()
        var ok = false
        try {
            if (muxerStarted) { muxer?.stop(); ok = true }
        } catch (_: Exception) {}
        try { muxer?.release() } catch (_: Exception) {}
        try { pfd?.close() } catch (_: Exception) {}
        try { projection.stop() } catch (_: Exception) {}
        val u = uri
        if (u != null) {
            if (ok) {
                val v = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
                ctx.contentResolver.update(u, v, null, null)
            } else {
                try { ctx.contentResolver.delete(u, null, null) } catch (_: Exception) {}
                return null
            }
        }
        return u
    }
}
