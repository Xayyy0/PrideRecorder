package com.grabador.pantalla

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.roundToInt

class RecorderService : Service() {

    companion object {
        const val ACTION_SHOW = "show"
        const val ACTION_START = "start"
        const val ACTION_STOP = "stop"
        const val ACTION_QUIT = "quit"
        private const val CHANNEL = "grabacion"
        private const val NOTIF_ID = 7
    }

    private enum class St { IDLE, COUNT, PREP, REC, PAUSED, SAVING }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var overlay: LinearLayout? = null
    private var ivMain: ImageView? = null
    private var tvTime: TextView? = null
    private var ivPause: ImageView? = null
    private var ivStop: ImageView? = null
    private lateinit var lp: WindowManager.LayoutParams

    private var recorder: ScreenRecorder? = null
    private var st = St.IDLE
    private var startMs = 0L
    private var pausedMs = 0L
    private var pauseBeginMs = 0L

    private val tick = object : Runnable {
        override fun run() {
            if (st == St.REC) {
                val s = (SystemClock.elapsedRealtime() - startMs - pausedMs) / 1000
                tvTime?.text = fmt(s)
                handler.postDelayed(this, 250)
            }
        }
    }

    private fun fmt(s: Long): String {
        val h = s / 3600; val m = (s % 3600) / 60; val sec = s % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%02d:%02d".format(m, sec)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Grabación de pantalla", NotificationManager.IMPORTANCE_LOW))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_SHOW -> {
                goForeground(false)
                showOverlay()
            }
            ACTION_START -> {
                val code = intent.getIntExtra("code", 0)
                @Suppress("DEPRECATION")
                val data = intent.getParcelableExtra<Intent>("data")
                if (data != null) beginRecording(code, data) else resetUi()
            }
            ACTION_STOP -> stopRecording()
            ACTION_QUIT -> {
                stopRecording()
                removeOverlay()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    // ---------- Notificación / foreground ----------
    private fun micGranted() = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun notification(rec: Boolean): Notification {
        val stop = PendingIntent.getService(
            this, 0, Intent(this, RecorderService::class.java).setAction(if (rec) ACTION_STOP else ACTION_QUIT),
            PendingIntent.FLAG_IMMUTABLE
        )
        val b = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle(if (rec) "Grabando pantalla…" else "Botón de grabación activo")
            .setOngoing(true)
        b.addAction(Notification.Action.Builder(null, if (rec) "Detener" else "Cerrar botón", stop).build())
        return b.build()
    }

    private fun goForeground(rec: Boolean) {
        val n = notification(rec)
        if (Build.VERSION.SDK_INT >= 34) {
            var type = if (rec) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            else ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            if (rec && micGranted() && Settings.audio(this).let { it == 0 || it == 2 })
                type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            try {
                startForeground(NOTIF_ID, n, type)
            } catch (e: SecurityException) {
                startForeground(NOTIF_ID, n, type and ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE.inv())
            }
        } else if (Build.VERSION.SDK_INT >= 29 && rec) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    // ---------- Grabación ----------
    private fun beginRecording(code: Int, data: Intent) {
        try {
            goForeground(true)
            val mpm = getSystemService(MediaProjectionManager::class.java)
            val projection = mpm.getMediaProjection(code, data)

            val bounds = wm.maximumWindowMetrics.bounds
            var w = bounds.width(); var h = bounds.height()
            val target = Settings.resHeights[Settings.res(this)]
            val shortSide = min(w, h)
            if (target in 1 until shortSide) {
                val k = target.toDouble() / shortSide
                w = (w * k).roundToInt(); h = (h * k).roundToInt()
            }
            w = w and 1.inv(); h = h and 1.inv()
            val fps = Settings.fpsList[Settings.fps(this)]
            val bitrate = (w.toDouble() * h * fps * Settings.qualityFactor[Settings.quality(this)])
                .coerceIn(1_000_000.0, 80_000_000.0).toInt()

            val rec = ScreenRecorder(
                this, projection, w, h, resources.displayMetrics.densityDpi,
                fps, bitrate, Settings.audio(this), micGranted(), Settings.force(this) == 0
            )
            recorder = rec
            rec.onError = { msg ->
                handler.post {
                    if (recorder === rec) {
                        guardarError(msg)
                        toast("La grabación se detuvo. Detalles del error dentro de la app.")
                        forceStop()
                    }
                }
            }
            // Mientras corre el temporizador se consultan las capacidades del codificador
            val pre = Thread { try { rec.preflight() } catch (_: Throwable) {} }
            pre.start()

            pausedMs = 0L
            var n = Settings.countSecs[Settings.countdown(this)]
            st = St.COUNT
            render()
            val countdown = object : Runnable {
                override fun run() {
                    if (st != St.COUNT) return
                    if (n > 0) {
                        tvTime?.text = "$n…"; n--
                        handler.postDelayed(this, 1000)
                    } else {
                        st = St.PREP
                        render()
                        Thread {
                            try { pre.join(10000) } catch (_: Exception) {}
                            val err: Throwable? = try { rec.start(); null } catch (e: Throwable) { e }
                            handler.post {
                                if (recorder !== rec) {
                                    Thread { try { rec.stop() } catch (_: Throwable) {} }.start()
                                    return@post
                                }
                                if (err == null) {
                                    if (rec.warnings.isNotEmpty()) toast("Grabando. Aviso: " + rec.warnings.joinToString(", "))
                                    st = St.REC
                                    startMs = SystemClock.elapsedRealtime()
                                    pausedMs = 0L
                                    render()
                                    handler.post(tick)
                                } else {
                                    guardarError(describe(err))
                                    toast("No se pudo iniciar. Detalles del error dentro de la app.")
                                    recorder = null
                                    resetUi()
                                }
                            }
                        }.start()
                    }
                }
            }
            handler.post(countdown)
        } catch (e: Exception) {
            guardarError(describe(e))
            toast("Error al iniciar. Detalles del error dentro de la app.")
            recorder = null
            resetUi()
        }
    }

    private fun togglePause() {
        val rec = recorder ?: return
        when (st) {
            St.REC -> {
                rec.pause()
                pauseBeginMs = SystemClock.elapsedRealtime()
                st = St.PAUSED
                render()
            }
            St.PAUSED -> {
                pausedMs += SystemClock.elapsedRealtime() - pauseBeginMs
                rec.resume()
                st = St.REC
                render()
                handler.post(tick)
            }
            else -> {}
        }
    }

    /** Detiene desde el botón o la notificación (no durante preparación/guardado). */
    private fun stopRecording() {
        if (st == St.PREP || st == St.SAVING) return
        forceStop()
    }

    private fun forceStop() {
        val rec = recorder
        if (rec == null) { resetUi(); return }
        val wasRecording = st == St.REC || st == St.PAUSED
        recorder = null
        handler.removeCallbacks(tick)
        st = St.SAVING
        render()
        Thread {
            val uri = try { rec.stop() } catch (e: Throwable) { null }
            handler.post {
                if (uri != null) toast("Video guardado en Películas/GrabadorPantalla")
                else if (wasRecording) toast("No se pudo guardar el video")
                resetUi()
            }
        }.start()
    }

    private fun resetUi() {
        st = St.IDLE
        render()
        if (overlay != null) goForeground(false)
    }

    private fun guardarError(msg: String) {
        getSharedPreferences("ajustes", MODE_PRIVATE).edit().putString("ultimo_error", msg).apply()
    }

    private fun toast(t: String) = Toast.makeText(applicationContext, t, Toast.LENGTH_LONG).show()

    // ---------- Botón flotante ----------
    private fun showOverlay() {
        if (overlay != null) return
        val d = resources.displayMetrics.density
        val scale = Settings.btnScale[Settings.btnSize(this)]
        val size = (44 * d * scale).toInt()
        val pad = (9 * d * scale).toInt()

        fun icon(res: Int) = ImageView(this).apply {
            setImageResource(res)
            setPadding(pad, pad, pad, pad)
        }
        ivMain = icon(R.drawable.ic_video)
        ivPause = icon(R.drawable.ic_pause)
        ivStop = icon(R.drawable.ic_stop)
        tvTime = TextView(this).apply {
            text = "00:00"
            textSize = 15f * scale
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            setTextColor(Color.WHITE)
            setPadding((6 * d).toInt(), 0, (8 * d).toInt(), 0)
        }
        overlay = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding((5 * d).toInt(), (5 * d).toInt(), (5 * d).toInt(), (5 * d).toInt())
            background = GradientDrawable().apply {
                cornerRadius = 100 * d
                setColor(Color.argb(235, 20, 24, 38))
                setStroke((1 * d).toInt().coerceAtLeast(1), Color.argb(70, 255, 255, 255))
            }
            addView(ivMain, LinearLayout.LayoutParams(size, size))
            addView(tvTime)
            addView(ivPause, LinearLayout.LayoutParams(size, size))
            addView(ivStop, LinearLayout.LayoutParams(size, size))
        }
        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = (12 * d).toInt(); y = (180 * d).toInt() }

        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var moved = false
        overlay!!.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; startX = lp.x; startY = lp.y; moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX; val dy = e.rawY - downY
                    if (abs(dx) > 12 * d || abs(dy) > 12 * d) moved = true
                    if (moved) {
                        lp.x = startX + dx.toInt(); lp.y = startY + dy.toInt()
                        wm.updateViewLayout(overlay, lp)
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved) onTap(e.x)
            }
            true
        }
        st = St.IDLE
        render()
        wm.addView(overlay, lp)
        Settings.setOverlay(this, true)
    }

    private fun hit(v: View?, x: Float) = v != null && v.visibility == View.VISIBLE && x >= v.left && x <= v.right

    private fun onTap(x: Float) {
        when (st) {
            St.IDLE -> if (hit(ivMain, x)) startFlow()
            St.COUNT -> if (hit(ivStop, x)) stopRecording()
            St.REC, St.PAUSED -> {
                if (hit(ivPause, x)) togglePause()
                else if (hit(ivStop, x)) stopRecording()
            }
            else -> {}
        }
    }

    private fun startFlow() {
        if (recorder == null) startActivity(
            Intent(this, ProjectionActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION or Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
        )
    }

    private fun show(v: View?, on: Boolean) { v?.visibility = if (on) View.VISIBLE else View.GONE }

    private fun render() {
        if (overlay == null) return
        when (st) {
            St.IDLE -> {
                ivMain?.setImageResource(R.drawable.ic_video)
                show(ivMain, true); show(tvTime, false); show(ivPause, false); show(ivStop, false)
            }
            St.COUNT -> {
                show(ivMain, false); show(tvTime, true); show(ivPause, false); show(ivStop, true)
                ivStop?.setImageResource(R.drawable.ic_stop)
            }
            St.PREP -> {
                show(ivMain, false); tvTime?.text = "Preparando…"; show(tvTime, true); show(ivPause, false); show(ivStop, false)
            }
            St.REC -> {
                ivMain?.setImageResource(R.drawable.ic_record)
                ivPause?.setImageResource(R.drawable.ic_pause)
                show(ivMain, true); show(tvTime, true); show(ivPause, true); show(ivStop, true)
            }
            St.PAUSED -> {
                ivMain?.setImageResource(R.drawable.ic_record_idle)
                ivPause?.setImageResource(R.drawable.ic_play)
                show(ivMain, true); show(tvTime, true); show(ivPause, true); show(ivStop, true)
            }
            St.SAVING -> {
                show(ivMain, false); tvTime?.text = "Guardando…"; show(tvTime, true); show(ivPause, false); show(ivStop, false)
            }
        }
    }

    private fun removeOverlay() {
        overlay?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        overlay = null
        Settings.setOverlay(this, false)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        removeOverlay()
        super.onDestroy()
    }
}
