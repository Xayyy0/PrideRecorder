package com.grabador.pantalla

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings as AndroidSettings
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        root.addView(TextView(this).apply {
            text = "Grabador de pantalla"
            textSize = 26f
            setTextColor(Color.BLACK)
        })
        root.addView(TextView(this).apply {
            text = "Configura la calidad y toca el botón para mostrar el botón flotante. " +
                "Desde ahí inicias y detienes la grabación."
            setPadding(0, pad / 2, 0, pad)
        })

        addSpinner(root, "Resolución", Settings.resolutions, Settings.res(this)) { Settings.set(this, "res", it) }
        addSpinner(root, "Fotogramas por segundo (FPS)", Settings.fpsList.map { "$it fps" }, Settings.fps(this)) { Settings.set(this, "fps", it) }
        addSpinner(root, "Calidad (bitrate)", Settings.qualities, Settings.quality(this)) { Settings.set(this, "quality", it) }
        addSpinner(root, "Audio", Settings.audioModes, Settings.audio(this)) { Settings.set(this, "audio", it) }

        root.addView(Button(this).apply {
            text = "Mostrar botón flotante"
            setOnClickListener { mostrarBoton() }
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = pad })

        root.addView(Button(this).apply {
            text = "Ocultar botón flotante"
            setOnClickListener {
                startService(Intent(this@MainActivity, RecorderService::class.java).setAction(RecorderService.ACTION_QUIT))
            }
        })

        root.addView(TextView(this).apply {
            text = "Los videos se guardan en Películas/GrabadorPantalla (aparecen en la galería)."
            setPadding(0, pad, 0, 0)
        })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun addSpinner(parent: LinearLayout, label: String, items: List<String>, selected: Int, onPick: (Int) -> Unit) {
        parent.addView(TextView(this).apply { text = label; setPadding(0, 24, 0, 0) })
        parent.addView(Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items)
            setSelection(selected)
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) = onPick(pos)
                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
        })
    }

    private fun mostrarBoton() {
        if (!AndroidSettings.canDrawOverlays(this)) {
            Toast.makeText(this, "Activa \"Mostrar sobre otras apps\" para este grabador", Toast.LENGTH_LONG).show()
            startActivity(Intent(AndroidSettings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val need = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            need += Manifest.permission.RECORD_AUDIO
        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            need += Manifest.permission.POST_NOTIFICATIONS
        if (need.isNotEmpty()) {
            requestPermissions(need.toTypedArray(), 1)
            return
        }
        startForegroundService(Intent(this, RecorderService::class.java).setAction(RecorderService.ACTION_SHOW))
        moveTaskToBack(true)
    }

    @Deprecated("Deprecated in Java")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        mostrarBoton()
    }
}
