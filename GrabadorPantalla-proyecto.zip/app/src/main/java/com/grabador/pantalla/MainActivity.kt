package com.grabador.pantalla

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings as AndroidSettings
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private var scroll: ScrollView? = null

    private class Pal(
        val bg: Int, val card: Int, val text: Int, val sub: Int,
        val accent: Int, val line: Int, val dark: Boolean
    )

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun palette(): Pal {
        val dark = when (Settings.theme(this)) {
            1 -> true
            2 -> (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
            else -> false
        }
        return if (dark) Pal(
            Color.parseColor("#0E1118"), Color.parseColor("#1A1E2A"), Color.parseColor("#F2F4FA"),
            Color.parseColor("#9AA1B5"), Color.parseColor("#5B8CFF"), Color.parseColor("#2A2F3E"), true
        ) else Pal(
            Color.parseColor("#EEF1FB"), Color.WHITE, Color.parseColor("#12141F"),
            Color.parseColor("#5B6075"), Color.parseColor("#2159E8"), Color.parseColor("#E3E6F0"), false
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        build()
    }

    override fun onResume() {
        super.onResume()
        build()
    }

    // ---------- helpers de vistas ----------
    private fun tv(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun lp(top: Int = 0) = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = dp(top) }

    private fun section(pal: Pal, t: String) = tv(t.uppercase(), 13f, pal.sub, true).apply {
        letterSpacing = 0.06f
        setPadding(dp(4), 0, 0, 0)
    }

    private fun card(pal: Pal) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = GradientDrawable().apply {
            setColor(pal.card)
            cornerRadius = dp(22).toFloat()
        }
        elevation = dp(2).toFloat()
    }

    private fun row(
        card: LinearLayout, pal: Pal, icon: Int, title: String, sub: String, last: Boolean,
        onClick: (() -> Unit)? = null, sw: Boolean? = null, onSw: ((Boolean) -> Unit)? = null
    ) {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(14), dp(14), dp(14))
        }
        r.addView(ImageView(this).apply {
            setImageResource(icon)
            setColorFilter(pal.accent)
        }, LinearLayout.LayoutParams(dp(30), dp(30)))
        r.addView(View(this).apply { setBackgroundColor(pal.line) },
            LinearLayout.LayoutParams(dp(1), dp(38)).apply { leftMargin = dp(14); rightMargin = dp(14) })
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(tv(title, 17f, pal.text, true))
        col.addView(tv(sub, 14f, pal.sub))
        r.addView(col, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        if (sw != null) {
            val s = Switch(this).apply {
                isChecked = sw
                val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
                thumbTintList = ColorStateList(states, intArrayOf(Color.WHITE, Color.parseColor("#F5F5F5")))
                trackTintList = ColorStateList(states, intArrayOf(pal.accent, Color.parseColor("#B8BDCB")))
                setOnCheckedChangeListener { _, c -> onSw?.invoke(c) }
            }
            r.addView(s)
            r.setOnClickListener { s.toggle() }
        } else {
            r.addView(ImageView(this).apply {
                setImageResource(R.drawable.ic_chevron)
                setColorFilter(pal.sub)
            }, LinearLayout.LayoutParams(dp(24), dp(24)))
            if (onClick != null) r.setOnClickListener { onClick() }
        }
        card.addView(r, lp())
        if (!last) card.addView(View(this).apply { setBackgroundColor(pal.line) },
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1)).apply { leftMargin = dp(18) })
    }

    private fun pick(title: String, items: List<String>, sel: Int, onPick: (Int) -> Unit) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setSingleChoiceItems(items.toTypedArray(), sel) { dlg, which ->
                onPick(which)
                dlg.dismiss()
                build()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun button(pal: Pal, icon: Int, label: String, filled: Boolean, onClick: () -> Unit): LinearLayout {
        val b = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(16), dp(12), dp(16))
            background = GradientDrawable().apply {
                cornerRadius = dp(18).toFloat()
                if (filled) setColor(pal.accent) else {
                    setColor(pal.card)
                    setStroke(dp(1), pal.line)
                }
            }
        }
        b.addView(ImageView(this).apply {
            setImageResource(icon)
            setColorFilter(if (filled) Color.WHITE else pal.text)
        }, LinearLayout.LayoutParams(dp(22), dp(22)).apply { rightMargin = dp(8) })
        b.addView(tv(label, 16f, if (filled) Color.WHITE else pal.text, true))
        b.setOnClickListener { onClick() }
        return b
    }

    // ---------- pantalla ----------
    private fun build() {
        val pal = palette()
        val keep = scroll?.scrollY ?: 0
        window.statusBarColor = pal.bg
        window.navigationBarColor = pal.bg
        window.decorView.systemUiVisibility =
            if (pal.dark) 0 else (View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(pal.bg)
        }
        root.setOnApplyWindowInsetsListener { v, insets ->
            v.setPadding(insets.systemWindowInsetLeft, insets.systemWindowInsetTop,
                insets.systemWindowInsetRight, insets.systemWindowInsetBottom)
            insets
        }

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }

        // Encabezado
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_video)
            setPadding(dp(17), dp(17), dp(17), dp(17))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.parseColor("#3A74FF"), Color.parseColor("#1A45C8"))
            ).apply { cornerRadius = dp(20).toFloat() }
        }, LinearLayout.LayoutParams(dp(72), dp(72)))
        val titles = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), 0, 0, 0)
        }
        titles.addView(tv("Grabador\nde pantalla", 28f, pal.text, true))
        titles.addView(tv("Configura tus grabaciones fácilmente", 14f, pal.sub))
        head.addView(titles)
        content.addView(head, lp())

        // Banner de estado
        val on = Settings.overlayOn(this)
        val banner = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(18))
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(Color.parseColor("#1F55E0"), Color.parseColor("#4D86FF"))
            ).apply { cornerRadius = dp(22).toFloat() }
        }
        banner.addView(ImageView(this).apply {
            setImageResource(if (on) R.drawable.ic_video else R.drawable.ic_play)
            setPadding(dp(11), dp(11), dp(11), dp(11))
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.TRANSPARENT)
                setStroke(dp(2), Color.WHITE)
            }
        }, LinearLayout.LayoutParams(dp(52), dp(52)))
        val bt = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), 0, 0, 0)
        }
        bt.addView(tv(if (on) "Botón flotante activo" else "Listo para grabar", 20f, Color.WHITE, true))
        bt.addView(tv(
            if (on) "Toca el botón sobre tu juego para empezar a grabar."
            else "Personaliza la configuración y comienza a grabar tu pantalla.", 14f, Color.WHITE
        ))
        banner.addView(bt, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        content.addView(banner, lp(20))

        // Configuración de grabación
        content.addView(section(pal, "Configuración de grabación"), lp(24))
        val c1 = card(pal)
        row(c1, pal, R.drawable.ic_monitor, "Resolución", Settings.resolutions[Settings.res(this)], false, {
            pick("Resolución", Settings.resolutions, Settings.res(this)) { Settings.set(this, "res", it) }
        })
        row(c1, pal, R.drawable.ic_speed, "FPS", "${Settings.fpsList[Settings.fps(this)]} FPS", false, {
            pick("Fotogramas por segundo", Settings.fpsList.map { "$it FPS" }, Settings.fps(this)) { Settings.set(this, "fps", it) }
        })
        val forced = Settings.force(this) == 0
        row(c1, pal, R.drawable.ic_bolt, "Forzar FPS",
            if (forced) "Sí (pedir exactamente los FPS elegidos)" else "No (ajustar a lo que soporte el celular)",
            false, sw = forced, onSw = { Settings.set(this, "force", if (it) 0 else 1); build() })
        row(c1, pal, R.drawable.ic_diamond, "Calidad", Settings.qualities[Settings.quality(this)], false, {
            pick("Calidad (bitrate)", Settings.qualities, Settings.quality(this)) { Settings.set(this, "quality", it) }
        })
        row(c1, pal, R.drawable.ic_volume, "Audio", Settings.audioModes[Settings.audio(this)], true, {
            pick("Audio", Settings.audioModes, Settings.audio(this)) { Settings.set(this, "audio", it) }
        })
        content.addView(c1, lp(8))

        // Personalización
        content.addView(section(pal, "Personalización"), lp(24))
        val c2 = card(pal)
        row(c2, pal, R.drawable.ic_widgets, "Botón flotante", "Tamaño: " + Settings.btnSizes[Settings.btnSize(this)], false, {
            pick("Tamaño del botón flotante", Settings.btnSizes, Settings.btnSize(this)) { Settings.set(this, "btnsize", it) }
        })
        row(c2, pal, R.drawable.ic_timer, "Temporizador", Settings.countdowns[Settings.countdown(this)], true, {
            pick("Temporizador antes de grabar", Settings.countdowns, Settings.countdown(this)) { Settings.set(this, "countdown", it) }
        })
        content.addView(c2, lp(8))

        // Mis grabaciones
        content.addView(section(pal, "Mis grabaciones"), lp(24))
        val c3 = card(pal)
        row(c3, pal, R.drawable.ic_gallery, "Galería de grabaciones", "Ver, reproducir y gestionar tus videos", true, { abrirGaleria() })
        content.addView(c3, lp(8))

        // Apariencia
        content.addView(section(pal, "Apariencia"), lp(24))
        val c4 = card(pal)
        row(c4, pal, R.drawable.ic_palette, "Tema", Settings.themes[Settings.theme(this)], true, {
            pick("Tema", Settings.themes, Settings.theme(this)) { Settings.set(this, "theme", it) }
        })
        content.addView(c4, lp(8))

        // Último error (si lo hay)
        val err = getSharedPreferences("ajustes", MODE_PRIVATE).getString("ultimo_error", null)
        if (!err.isNullOrEmpty()) {
            content.addView(section(pal, "Último error"), lp(24))
            content.addView(TextView(this).apply {
                text = err
                setTextIsSelectable(true)
                setTextColor(Color.parseColor(if (pal.dark) "#FF8A80" else "#B71C1C"))
                textSize = 12f
                setPadding(dp(4), dp(6), dp(4), 0)
            }, lp(4))
        }

        val sv = ScrollView(this).apply { isVerticalScrollBarEnabled = false }
        sv.addView(content)
        scroll = sv
        root.addView(sv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        // Barra inferior
        val bar = LinearLayout(this).apply { setPadding(dp(16), dp(8), dp(16), dp(12)) }
        bar.addView(button(pal, R.drawable.ic_refresh, "Restablecer", false) {
            Settings.reset(this)
            Toast.makeText(this, "Ajustes restablecidos", Toast.LENGTH_SHORT).show()
            build()
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(button(pal, R.drawable.ic_video,
            if (on) "Ocultar botón flotante" else "Mostrar botón flotante", true) { toggleBoton(on) },
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.5f).apply { leftMargin = dp(12) })
        root.addView(bar, lp())

        setContentView(root)
        sv.post { sv.scrollTo(0, keep) }
    }

    // ---------- acciones ----------
    private fun abrirGaleria() {
        try {
            startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, "video/*"))
        } catch (e: Exception) {
            Toast.makeText(this, "Abre tu galería: los videos están en Películas/GrabadorPantalla", Toast.LENGTH_LONG).show()
        }
    }

    private fun toggleBoton(on: Boolean) {
        if (on) {
            startService(Intent(this, RecorderService::class.java).setAction(RecorderService.ACTION_QUIT))
            Settings.setOverlay(this, false)
            Handler(Looper.getMainLooper()).postDelayed({ build() }, 300)
        } else mostrarBoton()
    }

    private fun mostrarBoton() {
        if (!AndroidSettings.canDrawOverlays(this)) {
            Toast.makeText(this, "Activa \"Mostrar sobre otras apps\" para este grabador", Toast.LENGTH_LONG).show()
            startActivity(Intent(AndroidSettings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val need = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            need += Manifest.permission.RECORD_AUDIO
        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            need += Manifest.permission.POST_NOTIFICATIONS
        if (need.isNotEmpty()) {
            requestPermissions(need.toTypedArray(), 1)
            return
        }
        startForegroundService(Intent(this, RecorderService::class.java).setAction(RecorderService.ACTION_SHOW))
        Settings.setOverlay(this, true)
        moveTaskToBack(true)
    }

    @Deprecated("Deprecated in Java")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        mostrarBoton()
    }
}
